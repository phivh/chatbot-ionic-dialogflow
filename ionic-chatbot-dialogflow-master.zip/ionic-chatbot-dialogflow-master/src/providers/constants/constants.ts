//import { Injectable } from '@angular/core';
/*
  Generated class for the Constants provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
//@Injectable()
export class Constants {

  //BASE_URL = '';
  // BASE_URL = 'http://texconnect.kaasbox.com:5000';
  BASE_URL = 'http://ec2-52-207-253-82.compute-1.amazonaws.com:5000';

}
